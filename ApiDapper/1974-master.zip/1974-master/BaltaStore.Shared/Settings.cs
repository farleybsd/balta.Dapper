namespace BaltaStore.Shared
{
    public static class Settings
    {
        public static string ConnectionString = @"Server=.\sqlexpress;Database=baltastore;User ID=baltastore;Password=sqlexpress;";
    }
}